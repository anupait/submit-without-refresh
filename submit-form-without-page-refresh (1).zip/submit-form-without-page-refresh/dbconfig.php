<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'users';
$dbconfig = mysqli_connect($host,$username,$password,$database);
?>
